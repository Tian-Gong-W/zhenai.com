import csv
import time
import requests
import uuid
import hashlib
import random
import os

# =============================================================================
# 全国城市代码表（来源：珍爱网小程序内置字典接口）
# 用于搜索模式按城市精准采集，确保真正覆盖全国
# =============================================================================
CITY_CODE_MAP = {
    # 北京
    '朝阳区': 10102005,
    '海淀区': 10102008,
    '丰台区': 10102006,
    '昌平区': 10102013,
    '通州区': 10102011,
    '大兴区': 10102014,
    '西城区': 10102002,
    '房山区': 10102010,
    '顺义区': 10102012,
    '东城区': 10102001,
    '石景山区': 10102007,
    '怀柔区': 10102015,
    '门头沟区': 10102009,
    '密云区': 10102017,
    '延庆区': 10102018,
    '平谷区': 10102016,
    # 上海
    '闸北区': 10103005,
    '黄浦区': 10103008,
    '徐汇区': 10103002,
    '浦东新区': 10103001,
    '闵行区': 10103012,
    '宝山区': 10103011,
    '松江区': 10103015,
    '嘉定区': 10103013,
    '杨浦区': 10103007,
    '普陀区': 10103004,
    '青浦区': 10103016,
    '奉贤区': 10103018,
    '静安区': 10103010,
    '虹口区': 10103006,
    '金山区': 10103014,
    '长宁区': 10103003,
    '崇明区': 10103017,
    # 广东
    '广州': 10101002,
    '深圳': 10101201,
    '佛山': 10101003,
    '湛江': 10101004,
    '珠海': 10101005,
    '肇庆': 10101006,
    '东莞': 10101007,
    '惠州': 10101008,
    '中山': 10101011,
    '茂名': 10101012,
    '汕头': 10101013,
    '梅州': 10101014,
    '韶关': 10101015,
    '江门': 10101016,
    '清远': 10101018,
    '潮州': 10101020,
    '阳江': 10101022,
    '河源': 10101023,
    '揭阳': 10101026,
    '汕尾': 10101028,
    '云浮': 10101068,
    # 天津
    '和平区': 10104008,
    '河东区': 10104009,
    '河西区': 10104010,
    '南开区': 10104011,
    '河北区': 10104012,
    '红桥区': 10104013,
    '东丽区': 10104017,
    '西青区': 10104018,
    '滨海新区': 10104014,
    '津南区': 10104020,
    '武清区': 10104002,
    '宝坻区': 10104005,
    '静海区': 10104006,
    '宁河区': 10104003,
    '北辰区': 10104019,
    '蓟州区': 10104007,
    # 重庆
    '渝中区': 10105034,
    '渝北区': 10105040,
    '合川区': 10105013,
    '九龙坡区': 10105037,
    '沙坪坝区': 10105036,
    '永川区': 10105007,
    '巴南区': 10105041,
    '南岸区': 10105038,
    '江北区': 10105026,
    '北碚区': 10105024,
    '璧山区': 10105025,
    '大渡口区': 10105035,
    '万州区': 10105042,
    '开州区': 10105006,
    '梁平区': 10105021,
    '黔江区': 10105018,
    '武隆区': 10105003,
    '江津区': 10105029,
    '涪陵区': 10105028,
    '綦江区': 10105033,
    '大足区': 10105023,
    '长寿区': 10105016,
    '荣昌区': 10105008,
    '铜梁区': 10105010,
    '潼南区': 10105027,
    '南川区': 10105015,
    '云阳县': 10105019,
    '奉节县': 10105002,
    '忠县': 10105004,
    '垫江县': 10105020,
    '丰都县': 10105030,
    '巫山县': 10105005,
    '巫溪县': 10105017,
    '城口县': 10105032,
    '石柱土家族自治县': 10105012,
    '酉阳土家族苗族自治县': 10105044,
    '彭水苗族土家族自治县': 10105045,
    '秀山土家族苗族自治县': 10105043,
    # 安徽
    '合肥': 10106001,
    '淮南': 10106002,
    '蚌埠': 10106003,
    '宿州': 10106004,
    '阜阳': 10106005,
    '六安': 10106006,
    '滁州': 10106008,
    '芜湖': 10106009,
    '安庆': 10106011,
    '黄山': 10106012,
    '铜陵': 10106013,
    '淮北': 10106042,
    '亳州': 10106072,
    '马鞍山': 10106075,
    '池州': 10106079,
    '宣城': 10106080,
    # 甘肃
    '兰州': 10108001,
    '张掖': 10108002,
    '武威': 10108003,
    '酒泉': 10108004,
    '金昌': 10108006,
    '天水': 10108007,
    '定西': 10108008,
    '平凉': 10108009,
    '甘南': 10108012,
    '嘉峪关': 10108023,
    '庆阳': 10108064,
    '白银': 10108078,
    '陇南': 10108084,
    '临夏': 10108085,
    # 广西
    '南宁': 10109001,
    '柳州': 10109002,
    '钦州': 10109003,
    '百色': 10109004,
    '玉林': 10109005,
    '防城港': 10109006,
    '桂林': 10109007,
    '梧州': 10109008,
    '河池': 10109009,
    '北海': 10109010,
    '贵港': 10109014,
    '来宾': 10109018,
    '崇左': 10109083,
    '贺州': 10109089,
    # 贵州
    '贵阳': 10110001,
    '六盘水': 10110002,
    '安顺': 10110006,
    '遵义': 10110007,
    '毕节': 10110021,
    '铜仁': 10110055,
    '黔西南布依族苗族自治州': 10110082,
    '黔东南苗族侗族自治州': 10110083,
    '黔南布依族苗族自治州': 10110084,
    # 海南
    '海口': 10111001,
    '三亚': 10111002,
    '省直辖县级': 10111022,
    # 河北
    '石家庄': 10112001,
    '衡水': 10112002,
    '邢台': 10112003,
    '邯郸': 10112004,
    '沧州': 10112005,
    '唐山': 10112006,
    '廊坊': 10112007,
    '秦皇岛': 10112008,
    '承德': 10112009,
    '保定': 10112010,
    '张家口': 10112011,
    # 河南
    '郑州': 10113001,
    '新乡': 10113002,
    '安阳': 10113003,
    '许昌': 10113004,
    '驻马店': 10113005,
    '漯河': 10113006,
    '信阳': 10113007,
    '周口': 10113008,
    '洛阳': 10113009,
    '平顶山': 10113010,
    '三门峡': 10113011,
    '南阳': 10113012,
    '开封': 10113013,
    '商丘': 10113014,
    '鹤壁': 10113015,
    '濮阳': 10113016,
    '焦作': 10113017,
    '河南省直辖县级': 10113126,
    # 湖北
    '武汉': 10115001,
    '黄石': 10115002,
    '鄂州': 10115004,
    '咸宁': 10115006,
    '十堰': 10115007,
    '宜昌': 10115008,
    '恩施': 10115009,
    '荆州': 10115010,
    '黄冈': 10115011,
    '荆门': 10115012,
    '孝感': 10115013,
    '襄阳': 10115014,
    '随州': 10115062,
    '湖北省直辖县级': 10115085,
    # 湖南
    '长沙': 10116001,
    '株洲': 10116002,
    '益阳': 10116003,
    '岳阳': 10116004,
    '常德': 10116005,
    '娄底': 10116007,
    '怀化': 10116008,
    '衡阳': 10116009,
    '邵阳': 10116010,
    '郴州': 10116011,
    '张家界': 10116013,
    '湘潭': 10116014,
    '永州': 10116075,
    '湘西土家族苗族自治州': 10116097,
    # 江苏
    '南京': 10118001,
    '苏州': 10118002,
    '无锡': 10118003,
    '徐州': 10118004,
    '常州': 10118005,
    '镇江': 10118006,
    '连云港': 10118007,
    '盐城': 10118009,
    '扬州': 10118010,
    '南通': 10118011,
    '淮安': 10118016,
    '泰州': 10118051,
    '宿迁': 10118063,
    # 江西
    '南昌': 10119001,
    '九江': 10119002,
    '景德镇': 10119003,
    '上饶': 10119004,
    '鹰潭': 10119005,
    '宜春': 10119006,
    '萍乡': 10119007,
    '赣州': 10119008,
    '吉安': 10119009,
    '抚州': 10119010,
    '新余': 10119040,
    # 内蒙古
    '呼和浩特': 10121001,
    '包头': 10121003,
    '乌海': 10121005,
    '赤峰': 10121008,
    '通辽': 10121011,
    '锡林郭勒盟': 10121089,
    '阿拉善盟': 10121090,
    '兴安': 10121091,
    '鄂尔多斯': 10121092,
    '呼伦贝尔': 10121093,
    '巴彦淖尔': 10121094,
    '乌兰察布': 10121095,
    # 宁夏
    '银川': 10122001,
    '石嘴山': 10122002,
    '固原': 10122003,
    '吴忠': 10122010,
    '中卫': 10122011,
    # 青海
    '西宁': 10123001,
    '果洛': 10123002,
    '玉树': 10123003,
    '海西': 10123005,
    '海东地区': 10123045,
    '海北藏族自治州': 10123046,
    '黄南藏族自治州': 10123047,
    '海南藏族自治州': 10123048,
    # 山东
    '青岛': 10124001,
    '威海': 10124002,
    '济南': 10124003,
    '淄博': 10124004,
    '聊城': 10124005,
    '德州': 10124006,
    '东营': 10124007,
    '潍坊': 10124008,
    '烟台': 10124009,
    '泰安': 10124011,
    '菏泽': 10124012,
    '临沂': 10124013,
    '枣庄': 10124014,
    '济宁': 10124015,
    '日照': 10124016,
    '滨州': 10124018,
    '莱芜': 10124068,
    # 山西
    '太原': 10125001,
    '忻州': 10125003,
    '大同': 10125005,
    '临汾': 10125006,
    '运城': 10125008,
    '阳泉': 10125009,
    '长治': 10125010,
    '晋城': 10125011,
    '朔州': 10125034,
    '晋中': 10125107,
    '吕梁': 10125108,
    # 陕西
    '西安': 10126001,
    '渭南': 10126002,
    '延安': 10126003,
    '榆林': 10126005,
    '宝鸡': 10126006,
    '安康': 10126007,
    '汉中': 10126008,
    '铜川': 10126010,
    '咸阳': 10126011,
    '商洛': 10126098,
    # 四川
    '成都': 10127001,
    '乐山': 10127002,
    '凉山': 10127003,
    '绵阳': 10127005,
    '阿坝': 10127007,
    '雅安': 10127008,
    '甘孜': 10127009,
    '广元': 10127010,
    '南充': 10127011,
    '内江': 10127013,
    '自贡': 10127014,
    '宜宾': 10127015,
    '泸州': 10127016,
    '攀枝花': 10127017,
    '德阳': 10127018,
    '资阳': 10127021,
    '眉山': 10127056,
    '广安': 10127070,
    '遂宁': 10127117,
    '巴中': 10127125,
    '达州': 10127137,
    # 云南
    '昆明': 10130001,
    '曲靖': 10130002,
    '昭通': 10130003,
    '文山': 10130005,
    '大理': 10130007,
    '楚雄': 10130008,
    '临沧': 10130009,
    '保山': 10130010,
    '玉溪': 10130011,
    '丽江': 10130030,
    '普洱': 10130052,
    '红河': 10130098,
    '西双版纳傣族自治州': 10130127,
    '德宏傣族景颇族自治州': 10130128,
    '怒江傈僳族自治州': 10130129,
    '迪庆藏族自治州': 10130130,
    # 浙江
    '杭州': 10131001,
    '温州': 10131002,
    '宁波': 10131003,
    '绍兴': 10131004,
    '湖州': 10131005,
    '嘉兴': 10131006,
    '金华': 10131009,
    '丽水': 10131010,
    '衢州': 10131011,
    '台州': 10131012,
    '舟山': 10131015,
    # 福建
    '福州': 10107001,
    '厦门': 10107002,
    '泉州': 10107003,
    '南平': 10107004,
    '漳州': 10107007,
    '龙岩': 10107008,
    '三明': 10107009,
    '莆田': 10107010,
    '宁德': 10107013,
    # 黑龙江
    '哈尔滨': 10114001,
    '绥化': 10114002,
    '佳木斯': 10114003,
    '牡丹江': 10114004,
    '齐齐哈尔': 10114005,
    '大庆': 10114007,
    '大兴安岭': 10114008,
    '鸡西': 10114009,
    '鹤岗': 10114020,
    '双鸭山': 10114024,
    '伊春': 10114042,
    '黑河': 10114053,
    '七台河': 10114067,
    # 吉林
    '长春': 10117001,
    '吉林': 10117002,
    '通化': 10117004,
    '四平': 10117006,
    '白城': 10117007,
    '松原': 10117008,
    '辽源': 10117028,
    '白山': 10117048,
    '延边朝鲜族自治州': 10117049,
    # 辽宁
    '沈阳': 10120001,
    '铁岭': 10120002,
    '抚顺': 10120003,
    '鞍山': 10120004,
    '营口': 10120005,
    '大连': 10120006,
    '本溪': 10120007,
    '丹东': 10120008,
    '锦州': 10120009,
    '朝阳': 10120010,
    '阜新': 10120011,
    '盘锦': 10120012,
    '辽阳': 10120013,
    '葫芦岛': 10120014,
    # 西藏
    '拉萨': 10128001,
    '那曲': 10128002,
    '昌都': 10128003,
    '山南': 10128004,
    '日喀则': 10128005,
    '阿里': 10128006,
    '林芝': 10128007,
    # 新疆
    '乌鲁木齐': 10129001,
    '克拉玛依': 10129004,
    '阿勒泰': 10129006,
    '巴音郭楞': 10129007,
    '哈密': 10129008,
    '吐鲁番': 10129009,
    '阿克苏': 10129010,
    '喀什': 10129011,
    '和田': 10129012,
    '昌吉': 10129017,
    '塔城': 10129086,
    '克孜勒苏柯尔克孜自治州': 10129088,
    '博尔塔拉蒙古自治州': 10129089,
    '伊犁哈萨克自治州': 10129090,
    '自治区直辖县级': 10129091,
}

# =============================================================================
# 工具函数
# =============================================================================

def load_scraped_ids(cache_file="scraped_ids.txt"):
    scraped = set()
    if os.path.exists(cache_file):
        try:
            with open(cache_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        scraped.add(line)
        except Exception as e:
            print(f"读取历史ID缓存失败: {e}")
    return scraped

def save_scraped_id(mid, cache_file="scraped_ids.txt"):
    try:
        with open(cache_file, "a", encoding="utf-8") as f:
            f.write(f"{mid}\n")
    except Exception as e:
        print(f"保存历史ID缓存失败: {e}")

def ensure_csv_fieldnames(filepath, fieldnames):
    """旧 CSV 缺 VIP/紫图可见 时升级表头，避免追加错位。"""
    if not os.path.exists(filepath) or os.path.getsize(filepath) == 0:
        return
    try:
        with open(filepath, "r", newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            old_fields = list(reader.fieldnames or [])
            if old_fields == list(fieldnames):
                return
            rows = list(reader)
        with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                out = {k: (row.get(k) or "") for k in fieldnames}
                if not out.get("VIP"):
                    out["VIP"] = "否"
                if not out.get("紫图可见"):
                    out["紫图可见"] = "否"
                writer.writerow(out)
        print(f"CSV表头已升级为: {','.join(fieldnames)}")
    except Exception as e:
        print(f"升级CSV表头失败: {e}")


def append_to_csv(record, filepath, fieldnames):
    file_exists = os.path.exists(filepath) and os.path.getsize(filepath) > 0
    try:
        if file_exists:
            ensure_csv_fieldnames(filepath, fieldnames)
        with open(filepath, "a", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            if not file_exists:
                writer.writeheader()
            writer.writerow(record)
    except Exception as e:
        print(f"追加写入CSV文件失败: {e}")


# =============================================================================
# 爬虫核心类
# =============================================================================

class ZhenaiCrawler:
    def __init__(self, token, seedtoken, recommend_token=""):
        """
        :param token:           从抓包 Cookie 中获取的 token 字符串（登录态必填，游客模式留空""）
        :param seedtoken:       从抓包 Headers 中获取的 seedtoken 字符串
        :param recommend_token: 可选，从抓包获取的成家相亲 token 字符串
        """
        self.token = token
        self.seedtoken = seedtoken
        self.recommend_token = recommend_token
        self.session = requests.Session()

    # ------------------------------------------------------------------
    # 签名与 UA 生成
    # ------------------------------------------------------------------

    def generate_signature(self, nonce, timestamp, data):
        """生成符合成家相亲 API 接口签名校验的 signature"""
        app_secret = "a66a81665d7ce684410136080290f851"
        p = f"appKey=seed-zaq&appSecret={app_secret}&nonce={nonce}&timestamp={timestamp}&"
        for key in sorted(data.keys()):
            val = data[key] if data[key] is not None else ""
            p += f"{key}{val}"
        return hashlib.md5(p.encode("utf-8")).hexdigest().upper()

    def generate_ua(self, channel=925536, sub_channel=3, version="9.13.0", ver_num="52", token=None):
        """动态生成符合珍爱网小程序安全校验的 ua 字符串与哈希"""
        t = str(uuid.uuid4())
        a = token if token else (self.token if self.token else "^CE%JUm#r3w&)")
        i = a + f"{version}{ver_num}" + t
        r = 5381
        for char in i:
            r = (r + (r << 5) + ord(char)) & 0xFFFFFFFF
        hash_val = 2147483647 & r
        return f"h5/{version}/{ver_num}/0/0/0/{channel}/{sub_channel}/0/0/0/{t}/0/0/{hash_val}"

    def _common_headers(self, req_ua):
        """返回所有接口通用的请求头"""
        return {
            "ua": req_ua,
            "xweb_xhr": "1",
            "seedtoken": self.seedtoken,
            "cookie": f"token={self.token}" if self.token else "token=",
            "user-agent": (
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 "
                "MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI "
                "MiniProgramEnv/Windows WindowsWechat/WMPF "
                "WindowsWechat(0x63090a13) UnifiedPCLinuxWechat(0xf2741107) XWEB/14978"
            ),
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "referer": "https://servicewechat.com/wxeb13e85bef8b60d9/426/page-frame.html",
            "accept": "*/*",
        }

    # ------------------------------------------------------------------
    # 模式一：推荐接口（登录态=本地城市 / 游客态=全国混合池）
    # ------------------------------------------------------------------

    def get_recommend_list(self, page=1, page_size=20):
        """获取推荐会员列表的 ID 数组（自适应登录与游客态推荐接口）"""
        if self.token:
            url = "https://api.zhenai.com/seed/applet/recommend/getRecommendList"
            req_ua = self.generate_ua(token=self.token)
            params = {"page": page, "pageSize": page_size, "_method": "GET", "ua": req_ua}
        else:
            url = "https://api.zhenai.com/seed/applet/recommend/qualityRecommendNew"
            req_ua = self.generate_ua(token="")
            params = {
                "page": page, "pageSize": page_size,
                "gender": 1, "province": "[]", "city": "[]",
                "birthday": "", "birthYear": "",
                "_method": "GET", "ua": req_ua,
            }
        try:
            resp = self.session.get(url, params=params, headers=self._common_headers(req_ua))
            if resp.status_code == 200:
                result = resp.json().get("data", {}).get("list", [])
                ids = []
                for item in result:
                    if isinstance(item, int):
                        ids.append(item)
                    elif isinstance(item, dict) and item.get("objectID"):
                        ids.append(item["objectID"])
                return ids
            print(f"获取推荐列表失败: {resp.status_code} {resp.text[:200]}")
        except Exception as e:
            print(f"获取推荐列表网络异常: {e}")
        return []

    # ------------------------------------------------------------------
    # 模式二：搜索接口（登录态，按条件全国检索）
    # ------------------------------------------------------------------

    def search_members(self, page=1, page_size=20,
                       age_begin=-1, age_end=-1,
                       work_city=-1, gender=1):
        """
        通过条件搜索接口采集会员列表（需要登录态 token）。

        :param page:       当前页码
        :param page_size:  每页条数（最大建议 20）
        :param age_begin:  年龄下限，-1 表示不限
        :param age_end:    年龄上限，-1 表示不限
        :param work_city:  城市代码，-1 表示全国不限
        :param gender:     搜索对象性别：1=女，2=男
        :return:           会员基础信息字典列表（含 memberID/objectID、昵称、城市等）
        """
        if not self.token:
            print("⚠️ 搜索模式必须填入登录 token，当前为游客态，已跳过。")
            return []

        url = "https://api.zhenai.com/search/getConditionData.do"
        req_ua = self.generate_ua()
        payload = {
            "ageBegin":          age_begin,
            "ageEnd":            age_end,
            "heightBegin":       129,
            "heightEnd":         -1,
            "salaryBegin":       -1,
            "salaryEnd":         -1,
            "multiEducation":    "",
            "multiWorkCity":     work_city,
            "multiMarriage":     -1,
            "occupation":        -1,
            "multiHomeTown":     -1,
            "multiHouse":        -1,
            "car":               -1,
            "multiChildren":     -1,
            "multiConstellation":-1,
            "avatar":            -1,
            "zhenxin":           1,
            "identityOk":        1,
            "loginType":         3,
            "pageSize":          page_size,
            "page":              page,
            "ua":                req_ua,
        }
        try:
            resp = self.session.post(url, data=payload, headers=self._common_headers(req_ua))
            if resp.status_code == 200:
                data = resp.json()
                if data.get("isError"):
                    print(f"  搜索接口报错: {data.get('errorMessage')} (code={data.get('errorCode')})")
                    return [], False
                inner = data.get("data", {})
                members = inner.get("list", [])
                has_next = inner.get("hasNext", False)
                return members, has_next
            print(f"搜索接口 HTTP 错误: {resp.status_code} {resp.text[:200]}")
        except Exception as e:
            print(f"搜索接口网络异常: {e}")
        return [], False

    # ------------------------------------------------------------------
    # 模式三：圈子接口（登录态，按城市圈子采集会员）
    # ------------------------------------------------------------------

    def get_circles(self):
        """获取当前账号所在地的全部相亲圈子列表（含 circleId 与人数）"""
        url = "https://api.zhenai.com/applet/circle/list.do"
        req_ua = self.generate_ua()
        try:
            resp = self.session.post(url, data={"ua": req_ua}, headers=self._common_headers(req_ua))
            if resp.status_code == 200:
                return resp.json().get("data", {}).get("list", [])
        except Exception as e:
            print(f"获取圈子列表异常: {e}")
        return []

    def get_circle_moments(self, circle_id, page=1, page_size=20):
        """
        获取指定圈子内的动态列表，从中提取会员 ID。

        :param circle_id: 圈子 ID（从 get_circles() 中获取）
        :param page:      页码
        :param page_size: 每页条数
        :return:          该页圈子动态列表（每条含发布者 memberID）
        """
        url = "https://api.zhenai.com/applet/circle/getMomentList.do"
        req_ua = self.generate_ua()
        payload = {
            "circleId":  circle_id,
            "page":      page,
            "pageSize":  page_size,
            "_method":   "GET",
            "ua":        req_ua,
        }
        try:
            resp = self.session.post(url, data=payload, headers=self._common_headers(req_ua))
            if resp.status_code == 200:
                data = resp.json().get("data", {})
                moments = data.get("list", [])
                has_next = data.get("hasNext", False)
                return moments, has_next
        except Exception as e:
            print(f"获取圈子动态异常: {e}")
        return [], False

    # ------------------------------------------------------------------
    # 公共：获取个人详情 & 动态
    # ------------------------------------------------------------------

    def get_member_profile(self, object_id):
        """获取指定会员的详细信息"""
        url = "https://api.zhenai.com/profile/getObjectProfileForWeChat.do"
        req_ua = self.generate_ua()
        params = {"objectID": object_id, "wxApp": 1, "location": 0, "_method": "GET", "ua": req_ua}
        try:
            resp = self.session.get(url, params=params, headers=self._common_headers(req_ua))
            if resp.status_code == 200:
                return resp.json().get("data", {})
            print(f"获取会员 {object_id} 资料失败: {resp.status_code}")
        except Exception as e:
            print(f"获取会员 {object_id} 资料网络异常: {e}")
        return {}

    def parse_profile(self, info):
        """解析会员详细字典中的关键字段"""
        if not info:
            return None
        tags = []
        for section in info.get("basicDetailsList", []):
            for tag_item in section.get("detailListV2", []):
                tags.append(tag_item.get("tagName"))
        return {
            "ID":       info.get("memberID", ""),
            "昵称":     info.get("nickname", ""),
            "性别":     "女" if info.get("gender") == 1 else "男",
            "年龄":     info.get("age", ""),
            "居住地":   info.get("workCityString", ""),
            "月收入":   info.get("salaryString", ""),
            "学历":     info.get("educationString", ""),
            "婚姻状况": info.get("marriageString", ""),
            "标签":     " | ".join(tags),
            "独白":     info.get("introduce", {}).get("monologue", ""),
            "头像链接": info.get("avatarURL", ""),
            "VIP":      "是" if info.get("isZhenXinVip") else "否",
        }

    # 会激活「动态」入口的真实动态类型（图文/视频等）
    # 不含资料变更系统卡：4上传头像 5内心独白 6实名认证 8兴趣爱好
    FEED_MOMENT_TYPES = {0, 1, 2, 7, 12}

    def get_moments(self, object_id):
        """获取指定会员的动态列表，支持分页（最多 5 页）"""
        moments = []
        timestamp = 0
        for _ in range(5):
            req_ua = self.generate_ua()
            url = "https://api.zhenai.com/moment/getPersonalMomentsByWeChat.do"
            params = {
                "objectID": object_id, "limit": 10,
                "timestamp": timestamp, "momentType": 0,
                "_method": "GET", "ua": req_ua,
            }
            try:
                resp = self.session.get(url, params=params, headers=self._common_headers(req_ua))
                if resp.status_code == 200:
                    data = resp.json().get("data", {})
                    page_list = data.get("list", [])
                    if not page_list:
                        break
                    moments.extend(page_list)
                    if not data.get("hasNext", False):
                        break
                    last_time = page_list[-1].get("moment", {}).get("createTime")
                    if last_time:
                        timestamp = last_time
                    else:
                        break
                else:
                    break
            except Exception as e:
                print(f"    获取 {object_id} 动态网络异常: {e}")
                break
            time.sleep(0.2)
        return moments

    def get_show_moments(self, object_id):
        """
        资料卡「动态」入口同源接口。
        小程序展示条件：contents 过滤后 length>0（仅 momentCount 不够）。
        """
        req_ua = self.generate_ua()
        url = "https://api.zhenai.com/moment/getShowMomentsByWeChat.do"
        params = {
            "objectID": object_id, "limit": 15, "wxApp": 1,
            "_method": "GET", "ua": req_ua,
        }
        try:
            resp = self.session.get(url, params=params, headers=self._common_headers(req_ua))
            if resp.status_code == 200:
                return resp.json().get("data", {}) or {}
        except Exception as e:
            print(f"    获取 {object_id} 动态入口异常: {e}")
        return {}

    @staticmethod
    def _purple_window(cert_ts):
        """紫图窗口 = 当前实时时间向前 3 天（now-3天 ~ now）。cert_ts 参数保留兼容。"""
        now = time.time()
        return now - 3 * 86400, now

    def has_purple_panel(self, object_id, cert_ts, moments=None):
        """
        紫图可见（新标准）：
        1) 实名认证在「当前实时时间向前 3 天」内
        2) 动态窗口激活：最近 3 天内发布过一条动态，且排除 头像(type4)/独白(type5)/观点(type7)
        """
        if not cert_ts:
            return False
        win_start, win_end = self._purple_window(cert_ts)  # now-3天 ~ now

        # 条件1：实名认证在最近3天内
        if not (win_start <= cert_ts / 1000 < win_end):
            return False

        # 条件2：最近3天内有动态，排除 type4/5/7
        if moments is not None:
            has_dynamic = False
            for m in moments:
                mom = m.get("moment") or {}
                mtype = mom.get("type", -1)
                mts = mom.get("createTime", 0) or 0
                if mtype in (4, 5, 7):
                    continue
                if win_start <= mts / 1000 < win_end:
                    has_dynamic = True
                    break
            if not has_dynamic:
                return False
        return True

    def parse_moments_times(self, moments, object_id=None):
        """解析动态时间（最新、实名认证、最早）+ 紫图窗口是否真正激活动态入口"""
        if not moments:
            return "", "", "", False

        def fmt(ts):
            return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts / 1000)) if ts else ""

        latest = fmt(moments[0].get("moment", {}).get("createTime"))
        cert = ""
        cert_ts = 0
        for m in moments:
            if m.get("text") == "已完成人脸认证" or m.get("moment", {}).get("type") == 6:
                cert = fmt(m.get("moment", {}).get("createTime"))
                cert_ts = m.get("moment", {}).get("createTime", 0)
                break

        has_recent = False
        if cert_ts > 0:
            if object_id is not None:
                has_recent = self.has_purple_panel(object_id, cert_ts, moments=moments)
            else:
                cert_start, cert_end = self._purple_window(cert_ts)
                for m in moments:
                    mtype = m.get("moment", {}).get("type", -1)
                    mts = m.get("moment", {}).get("createTime", 0) or 0
                    if mtype != 6 and cert_start <= mts / 1000 < cert_end:
                        has_recent = True
                        break

        earliest = fmt(moments[-1].get("moment", {}).get("createTime")) if not cert else ""
        return latest, cert, earliest, has_recent


# =============================================================================
# 公共：处理单个会员 ID（查详情 → 过滤 → 抓动态 → 写 CSV）
# =============================================================================

FIELDNAMES = ["ID", "昵称", "性别", "年龄", "居住地", "月收入", "学历", "婚姻状况",
              "标签", "独白", "头像链接",
              "最新动态时间", "实名认证时间", "最早动态时间", "VIP", "紫图可见"]

def process_member(crawler, mid, scraped_ids, cache_file,
                   output_file, gender_filter, city_filter, extra_filters=None,
                   cert_days=0):
    """
    处理单个会员 ID。
    cert_days>0: 先查动态 → 实名不在N天内直接跳过（省1次详情API）
    """
    mid_str = str(mid)
    if mid_str in scraped_ids:
        return False

    # ====== 快速模式：先查动态 ======
    pre_moments = []
    if cert_days > 0:
        pre_moments = crawler.get_moments(mid)
        _, cert_time, _, _ = crawler.parse_moments_times(
            pre_moments, object_id=mid
        )
        # 没有实名 或 实名超过N天 → 跳过（紫图只打标签，不拦写入）
        if not cert_time:
            scraped_ids.add(mid_str)
            save_scraped_id(mid_str, cache_file)
            return False
        try:
            cert_dt = time.strptime(cert_time, "%Y-%m-%d %H:%M:%S")
            cert_ts = time.mktime(cert_dt)
            cutoff = time.time() - cert_days * 86400
            if cert_ts < cutoff:
                scraped_ids.add(mid_str)
                save_scraped_id(mid_str, cache_file)
                return False
        except Exception:
            pass

    raw_info = crawler.get_member_profile(mid)
    parsed = crawler.parse_profile(raw_info)

    # 记录已查询
    scraped_ids.add(mid_str)
    save_scraped_id(mid_str, cache_file)

    if not parsed:
        print(f"    解析会员 {mid} 失败或返回空")
        return False

    # 城市过滤
    if city_filter and city_filter not in parsed["居住地"]:
        print(f"    跳过: {parsed['昵称']} (居住地: {parsed['居住地']}，不含'{city_filter}')")
        return False

    # 性别过滤
    if gender_filter and parsed["性别"] != gender_filter:
        print(f"    跳过: {parsed['昵称']} (性别: {parsed['性别']}，不符合'{gender_filter}')")
        return False

    # 额外过滤（月收入/学历/婚姻）
    if extra_filters:
        income_f, edu_f, marriage_f = extra_filters
        if income_f and parsed.get("月收入", "") != income_f:
            print(f"    跳过: {parsed['昵称']} (月收入: {parsed.get('月收入')}，不符合'{income_f}')")
            return False
        if edu_f and parsed.get("学历", "") != edu_f:
            print(f"    跳过: {parsed['昵称']} (学历: {parsed.get('学历')}，不符合'{edu_f}')")
            return False
        if marriage_f and parsed.get("婚姻状况", "") != marriage_f:
            print(f"    跳过: {parsed['昵称']} (婚姻: {parsed.get('婚姻状况')}，不符合'{marriage_f}')")
            return False

    # 抓动态时间 / 紫图入口
    if cert_days > 0:
        latest, cert, earliest, has_real_moment = crawler.parse_moments_times(
            pre_moments, object_id=mid
        )
    else:
        moments = crawler.get_moments(mid)
        latest, cert, earliest, has_real_moment = crawler.parse_moments_times(
            moments, object_id=mid
        )
    parsed["最新动态时间"] = latest
    parsed["实名认证时间"] = cert
    parsed["最早动态时间"] = earliest
    parsed["VIP"] = parsed.get("VIP", "否")
    parsed["紫图可见"] = "是" if has_real_moment else "否"

    append_to_csv(parsed, output_file, FIELDNAMES)
    print(
        f"    🎉 写入: {parsed['昵称']} | {parsed['性别']} | {parsed['年龄']}岁 | "
        f"{parsed['居住地']} | 💰{parsed.get('月收入', '')} | 🎓{parsed.get('学历', '')} | 💍{parsed.get('婚姻状况', '')} | "
        f"最新动态:{latest or '无'} | 实名:{cert or '无'} | 紫图:{parsed['紫图可见']}"
    )
    return True


# =============================================================================
# 模式一入口：推荐模式（游客/登录）
# =============================================================================

def start_crawl_recommend(token, seedtoken, recommend_token="",
                          total_pages=30, output_file="zhenai_members.csv",
                          gender_filter=None, city_filter=None,
                          loop_interval_minutes=None):
    """
    推荐模式：
    - token 为空 → 游客态全国混合推荐（qualityRecommendNew），本地按城市过滤
    - token 非空 → 登录态本地城市推荐（getRecommendList）
    """
    crawler = ZhenaiCrawler(token=token, seedtoken=seedtoken, recommend_token=recommend_token)
    cache_file = "scraped_ids.txt"

    while True:
        scraped_ids = load_scraped_ids(cache_file)
        mode_desc = "登录态（本地城市）" if token else "游客态（全国混合池）"
        print(f"\n==========================================")
        print(f"【推荐模式 · {mode_desc}】开始新一轮抓取")
        print(f"已有历史记录: {len(scraped_ids)} 个  |  计划抓取: {total_pages} 页（最多 {total_pages*20} 个）")
        if city_filter:
            print(f"城市筛选: 只保留【{city_filter}】")
        if gender_filter:
            print(f"性别筛选: 只保留【{gender_filter}】性")
        print(f"==========================================")

        new_added = 0
        for page in range(1, total_pages + 1):
            member_ids = crawler.get_recommend_list(page=page, page_size=20)
            if not member_ids:
                print(f"第 {page} 页未获取到任何会员ID，停止翻页。")
                break

            new_ids = [m for m in member_ids if str(m) not in scraped_ids]
            if not new_ids:
                print(f"--- 第 {page} 页 ({len(member_ids)} 个) 全部为历史记录，跳过 ---")
                continue

            print(f"\n--- 第 {page} 页：{len(member_ids)} 个推荐，其中 {len(new_ids)} 个新会员 ---")
            for idx, mid in enumerate(member_ids, 1):
                if str(mid) in scraped_ids:
                    continue
                print(f"  [{idx}/{len(member_ids)}] ID: {mid}")
                if process_member(crawler, mid, scraped_ids, cache_file,
                                  output_file, gender_filter, city_filter):
                    new_added += 1
                time.sleep(0.25)

        print(f"\n🎉 本轮推荐模式结束！共新增 {new_added} 条记录 → {output_file}")

        if loop_interval_minutes is None:
            break
        print(f"⏰ 等待 {loop_interval_minutes} 分钟后自动开始下一轮...")
        try:
            for remaining in range(loop_interval_minutes * 60, 0, -1):
                if remaining % 60 == 0:
                    print(f"  还有 {remaining // 60} 分钟...")
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n👋 手动停止。")
            break


# =============================================================================
# 模式二入口：搜索模式（全国按条件检索，需登录 token）
# =============================================================================

def start_crawl_search(token, seedtoken,
                       age_begin=40, age_end=65,
                       work_city=-1,
                       output_file="zhenai_members.csv",
                       gender_filter="女", city_filter=None,
                       max_pages=500,
                       loop_interval_minutes=None):
    """
    搜索模式（需要登录 token）：
    通过 /search/getConditionData.do 按年龄段/城市条件全量采集。
    - work_city=-1  → 自动遍历全国所有城市（推荐！真正全国采集）
    - work_city=具体代码 → 只采集指定城市（如 10101201=深圳）
    - age_begin/age_end 年龄范围
    - max_pages  每个城市最多翻多少页（每页 20 条）
    """
    if not token:
        print("❌ 搜索模式必须填入登录 token！请在配置区填写 MY_COOKIE_TOKEN。")
        return

    crawler = ZhenaiCrawler(token=token, seedtoken=seedtoken)
    cache_file = "scraped_ids.txt"

    # 确定要遍历的城市列表
    if work_city == -1:
        # 全国模式：逐城市遍历
        cities_to_crawl = list(CITY_CODE_MAP.items())  # [(city_name, city_code), ...]
        print(f"\n🌏 全国模式：将逐城市遍历共 {len(cities_to_crawl)} 个城市")
    else:
        # 单城市模式：找出城市名
        name = next((k for k, v in CITY_CODE_MAP.items() if v == work_city), f"code={work_city}")
        cities_to_crawl = [(name, work_city)]

    while True:
        total_new = 0
        scraped_ids = load_scraped_ids(cache_file)
        print(f"\n==========================================")
        print(f"【搜索模式】年龄 {age_begin}-{age_end} 岁  |  共 {len(cities_to_crawl)} 个城市")
        print(f"已有历史记录: {len(scraped_ids)} 个")
        if gender_filter:
            print(f"性别筛选: 只保留【{gender_filter}】性")
        if city_filter:
            print(f"城市二次过滤: 只保留【{city_filter}】")
        print(f"==========================================")

        for city_name, city_code in cities_to_crawl:
            print(f"\n\n📍 开始采集城市: 【{city_name}】(code={city_code})")
            city_new = 0

            for page in range(1, max_pages + 1):
                members, has_next = crawler.search_members(
                    page=page, page_size=20,
                    age_begin=age_begin, age_end=age_end,
                    work_city=city_code, gender=1
                )

                if not members:
                    print(f"  第 {page} 页返回空，{city_name} 采集完毕。")
                    break

                page_ids = [
                    m.get("memberId") or m.get("memberID") or m.get("objectID")
                    for m in members
                    if m.get("memberId") or m.get("memberID") or m.get("objectID")
                ]

                new_ids = [m for m in page_ids if str(m) not in scraped_ids]
                skipped = len(page_ids) - len(new_ids)
                print(f"  第 {page} 页: {len(page_ids)} 个会员，{skipped} 个已跳过，{len(new_ids)} 个新会员")

                for mid in page_ids:
                    if str(mid) in scraped_ids:
                        continue
                    if process_member(crawler, mid, scraped_ids, cache_file,
                                      output_file, gender_filter, city_filter):
                        city_new += 1
                        total_new += 1
                    time.sleep(0.25)

                if not has_next:
                    print(f"  {city_name} 第 {page} 页无更多数据，下一城市。")
                    break

                time.sleep(0.25)

            print(f"  ✅ {city_name} 完成，本城市新增 {city_new} 条")

        print(f"\n🎉 本轮搜索模式全部城市遍历完成！共新增 {total_new} 条记录 → {output_file}")

        if loop_interval_minutes is None:
            break
        print(f"⏰ 等待 {loop_interval_minutes} 分钟后自动开始下一轮...")
        try:
            for remaining in range(loop_interval_minutes * 60, 0, -1):
                if remaining % 60 == 0:
                    print(f"  还有 {remaining // 60} 分钟...")
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n👋 手动停止。")
            break


# =============================================================================
# 模式三入口：圈子模式（按城市圈子采集，需登录 token）
# =============================================================================

def start_crawl_circle(token, seedtoken,
                       output_file="zhenai_members.csv",
                       gender_filter="女", city_filter=None,
                       max_pages_per_circle=50,
                       loop_interval_minutes=None):
    """
    圈子模式（需要登录 token）：
    通过 /applet/circle/list.do 获取当前账号所在地的所有相亲圈子，
    再遍历每个圈子内的动态，提取发帖会员 ID 并抓取详情。
    - 适合精准采集账号注册城市（如成都、北京）的本地用户
    """
    if not token:
        print("❌ 圈子模式必须填入登录 token！")
        return

    crawler = ZhenaiCrawler(token=token, seedtoken=seedtoken)
    cache_file = "scraped_ids.txt"

    while True:
        scraped_ids = load_scraped_ids(cache_file)
        print(f"\n==========================================")
        print(f"【圈子模式】获取本地相亲圈列表...")
        circles = crawler.get_circles()
        if not circles:
            print("未获取到任何圈子，请确认 token 是否有效。")
            break

        print(f"发现 {len(circles)} 个圈子：")
        for c in circles:
            print(f"  [{c.get('circleId')}] {c.get('circleName')}  人数:{c.get('userCount')}  动态:{c.get('momentCount')}")
        if city_filter:
            print(f"城市二次过滤: 只保留【{city_filter}】")
        print(f"==========================================")

        new_added = 0
        for circle in circles:
            circle_id = circle.get("circleId")
            circle_name = circle.get("circleName", "")
            print(f"\n📌 开始采集圈子: 【{circle_name}】(ID={circle_id})")

            for page in range(1, max_pages_per_circle + 1):
                moments, has_next = crawler.get_circle_moments(circle_id, page=page, page_size=20)
                if not moments:
                    print(f"  圈子 {circle_name} 第 {page} 页为空，跳出。")
                    break

                page_ids = []
                for m in moments:
                    # 圈子动态中发帖人信息在 owner 或 memberID 字段
                    mid = (m.get("owner") or {}).get("memberID") or m.get("memberID")
                    if mid:
                        page_ids.append(mid)

                new_ids = [m for m in page_ids if str(m) not in scraped_ids]
                print(f"  第 {page} 页: {len(page_ids)} 个发帖人，{len(new_ids)} 个新会员")

                for mid in page_ids:
                    if str(mid) in scraped_ids:
                        continue
                    print(f"  → ID: {mid}")
                    if process_member(crawler, mid, scraped_ids, cache_file,
                                      output_file, gender_filter, city_filter):
                        new_added += 1
                    time.sleep(0.25)

                if not has_next:
                    break
                time.sleep(0.25)

        print(f"\n🎉 本轮圈子模式结束！共新增 {new_added} 条记录 → {output_file}")

        if loop_interval_minutes is None:
            break
        print(f"⏰ 等待 {loop_interval_minutes} 分钟后自动开始下一轮...")
        try:
            for remaining in range(loop_interval_minutes * 60, 0, -1):
                if remaining % 60 == 0:
                    print(f"  还有 {remaining // 60} 分钟...")
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n👋 手动停止。")
            break


# =============================================================================
# 入口配置（直接运行此脚本时生效）
# =============================================================================

if __name__ == "__main__":
    # ====================== 填入您的新账号配置 ======================
    MY_COOKIE_TOKEN = os.environ.get("MY_COOKIE_TOKEN", "")
    MY_SEEDTOKEN = os.environ.get("MY_SEEDTOKEN", "")

    # ====================== 选择抓取模式 ======================
    # "recommend" → 推荐模式（游客/登录）
    # "search"    → 搜索模式（全国按条件，需 token）★ 当前选择
    # "circle"    → 圈子模式（本地城市圈，需 token）
    CRAWL_MODE = "search"

    # ====================== 搜索模式专用参数 ======================
    SEARCH_AGE_BEGIN = 40      # 年龄下限
    SEARCH_AGE_END   = 65      # 年龄上限
    SEARCH_WORK_CITY = -1      # 城市代码：-1 = 全国不限
    SEARCH_MAX_PAGES = 500     # 最多翻多少页（每页20条，500页=最多10000人）

    # ====================== 圈子模式专用参数 ======================
    CIRCLE_MAX_PAGES_PER_CIRCLE = 50   # 每个圈子最多抓多少页

    # ====================== 推荐模式专用参数 ======================
    RECOMMEND_TOTAL_PAGES = 30         # 每轮抓多少页推荐

    # ====================== 通用过滤参数 ======================
    GENDER_FILTER = "女"        # "女" / "男" / None（不限）
    CITY_FILTER   = None        # 二次城市过滤，如 "成都"，None 表示不限

    # ====================== 循环设置 ======================
    LOOP_INTERVAL_MINUTES = None   # None=单次运行，数字=每隔N分钟自动重跑

    # ====================== 输出文件 ======================
    OUTPUT_FILE = "zhenai_members.csv"
    # ==========================================================

    if CRAWL_MODE == "search":
        start_crawl_search(
            token       = MY_COOKIE_TOKEN,
            seedtoken   = MY_SEEDTOKEN,
            age_begin   = SEARCH_AGE_BEGIN,
            age_end     = SEARCH_AGE_END,
            work_city   = SEARCH_WORK_CITY,
            output_file = OUTPUT_FILE,
            gender_filter = GENDER_FILTER,
            city_filter   = CITY_FILTER,
            max_pages     = SEARCH_MAX_PAGES,
            loop_interval_minutes = LOOP_INTERVAL_MINUTES,
        )

    elif CRAWL_MODE == "circle":
        start_crawl_circle(
            token       = MY_COOKIE_TOKEN,
            seedtoken   = MY_SEEDTOKEN,
            output_file = OUTPUT_FILE,
            gender_filter = GENDER_FILTER,
            city_filter   = CITY_FILTER,
            max_pages_per_circle  = CIRCLE_MAX_PAGES_PER_CIRCLE,
            loop_interval_minutes = LOOP_INTERVAL_MINUTES,
        )

    elif CRAWL_MODE == "recommend":
        start_crawl_recommend(
            token       = MY_COOKIE_TOKEN,
            seedtoken   = MY_SEEDTOKEN,
            output_file = OUTPUT_FILE,
            total_pages   = RECOMMEND_TOTAL_PAGES,
            gender_filter = GENDER_FILTER,
            city_filter   = CITY_FILTER,
            loop_interval_minutes = LOOP_INTERVAL_MINUTES,
        )

    else:
        print(f"❌ 未知 CRAWL_MODE='{CRAWL_MODE}'，请填写 'search' / 'circle' / 'recommend'")

