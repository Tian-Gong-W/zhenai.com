#!/usr/bin/env python3
"""群推送脚本 - 仅推送「今天实名 + 紫图可见=是」用户

紫图可见=是 的含义（由采集端判定，与手动核验标准一致）：
- 紫图窗口内有非 type6 动态（面板激活）
- 且搜索/详情卡有「动态」入口（getShowMomentsByWeChat.contents 落在紫图窗口）
- 不是仅有照片数/观点数/已实名徽章
"""

import os, csv, requests
from datetime import datetime, timedelta

BASE_DIR = "/root/zhenai"
TG_BOT_TOKEN = os.environ.get("TG_BOT_TOKEN", "")
GROUP_CHAT_ID = os.environ.get("GROUP_CHAT_ID", "")

today = datetime.now().strftime("%Y-%m-%d")
yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
day_before = (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d")
ALLOW_DAYS = {today, yesterday, day_before}

users = []
main_csv = os.path.join(BASE_DIR, "zhenai_members.csv")
if os.path.exists(main_csv):
    with open(main_csv, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cert = (row.get("实名认证时间") or "").strip()
            purple = (row.get("紫图可见") or "").strip()
            if not cert or cert == "无":
                continue
            # 最近三天实名，且采集时已判定动态入口激活（紫图可见）
            if cert[:10] not in ALLOW_DAYS:
                continue
            if purple != "是":
                continue
            users.append(row)

pushed_file = os.path.join(BASE_DIR, ".pushed_cert_ids.txt")
pushed = set()
if os.path.exists(pushed_file):
    with open(pushed_file) as f:
        pushed = set(line.strip() for line in f)

new_users = [r for r in users if (r.get("ID") or "").strip() not in pushed]

for u in new_users:
    uid = (u.get("ID") or "").strip()
    cert = (u.get("实名认证时间") or "").strip()
    if cert.startswith(today):
        day_tag = "今天"
    elif cert.startswith(yesterday):
        day_tag = "昨天"
    else:
        day_tag = "前天"
    lines = [
        "🔔 " + day_tag + "新实名·紫图",
        "ID:%s | %s | %s岁 | %s | %s | 实名:%s"
        % (
            uid,
            u.get("昵称", ""),
            u.get("年龄", ""),
            u.get("居住地", ""),
            u.get("月收入", ""),
            u.get("实名认证时间", ""),
        ),
    ]
    msg = "\n".join(lines)
    try:
        resp = requests.post(
            "https://api.telegram.org/bot" + TG_BOT_TOKEN + "/sendMessage",
            json={"chat_id": GROUP_CHAT_ID, "text": msg},
            timeout=10
        )
        if resp.status_code == 200:
            with open(pushed_file, "a") as f:
                f.write(uid + "\n")
    except Exception:
        pass
