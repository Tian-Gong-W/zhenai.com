#!/usr/bin/env python3
"""
TON MAN 2.0 — 珍爱网数据采集 可视界面 (Flask)
"""

import os, sys, io, json, time, queue, threading, requests, csv
from flask import Flask, Response, request, jsonify, send_file, render_template_string

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

# 导入原脚本
import importlib.util
_spec = importlib.util.spec_from_file_location("tonmam", os.path.join(BASE_DIR, "TON-MAM.py"))
ton = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ton)

# ========== 配置 ==========
MY_TOKEN = os.environ.get("MY_TOKEN", "")
MY_SEED = os.environ.get("MY_SEED", "")
TG_BOT_TOKEN = os.environ.get("TG_BOT_TOKEN", "")
TG_CHAT_ID = os.environ.get("TG_CHAT_ID", "")
GROUP_CHAT_ID = os.environ.get("GROUP_CHAT_ID", "")
EXCLUDED = set()

PROVINCE_MAP = {
    "北京": ["朝阳区","海淀区","丰台区","昌平区","通州区","大兴区","西城区","房山区","顺义区","东城区","石景山区","怀柔区","门头沟区","密云区","延庆区","平谷区"],
    "上海": ["闸北区","黄浦区","徐汇区","浦东新区","闵行区","宝山区","松江区","嘉定区","杨浦区","普陀区","青浦区","奉贤区","静安区","虹口区","金山区","长宁区","崇明区"],
    "广东": ["广州","深圳","佛山","湛江","珠海","肇庆","东莞","惠州","中山","茂名","汕头","梅州","韶关","江门","清远","潮州","阳江","河源","揭阳","汕尾","云浮"],
    "天津": ["和平区","河东区","河西区","南开区","河北区","红桥区","东丽区","西青区","滨海新区","津南区","武清区","宝坻区","静海区","宁河区","北辰区","蓟州区"],
    "重庆": ["渝中区","渝北区","合川区","九龙坡区","沙坪坝区","永川区","巴南区","南岸区","江北区","北碚区","璧山区","大渡口区","万州区","开州区","梁平区","黔江区","武隆区","江津区","涪陵区","綦江区","大足区","长寿区","荣昌区","铜梁区","潼南区","南川区","云阳县","奉节县","忠县","垫江县","丰都县","巫山县","巫溪县","城口县","石柱土家族自治县","酉阳土家族苗族自治县","彭水苗族土家族自治县","秀山土家族苗族自治县"],
    "安徽": ["合肥","淮南","蚌埠","宿州","阜阳","六安","滁州","芜湖","安庆","黄山","铜陵","淮北","亳州","马鞍山","池州","宣城"],
    "甘肃": ["兰州","张掖","武威","酒泉","金昌","天水","定西","平凉","甘南","嘉峪关","庆阳","白银","陇南","临夏"],
    "广西": ["南宁","柳州","钦州","百色","玉林","防城港","桂林","梧州","河池","北海","贵港","来宾","崇左","贺州"],
    "贵州": ["贵阳","六盘水","安顺","遵义","毕节","铜仁","黔西南布依族苗族自治州","黔东南苗族侗族自治州","黔南布依族苗族自治州"],
    "海南": ["海口","三亚","省直辖县级"],
    "河北": ["石家庄","衡水","邢台","邯郸","沧州","唐山","廊坊","秦皇岛","承德","保定","张家口"],
    "河南": ["郑州","新乡","安阳","许昌","驻马店","漯河","信阳","周口","洛阳","平顶山","三门峡","南阳","开封","商丘","鹤壁","濮阳","焦作","河南省直辖县级"],
    "湖北": ["武汉","黄石","鄂州","咸宁","十堰","宜昌","恩施","荆州","黄冈","荆门","孝感","襄阳","随州","湖北省直辖县级"],
    "湖南": ["长沙","株洲","益阳","岳阳","常德","娄底","怀化","衡阳","邵阳","郴州","张家界","湘潭","永州","湘西土家族苗族自治州"],
    "江苏": ["南京","苏州","无锡","徐州","常州","镇江","连云港","盐城","扬州","南通","淮安","泰州","宿迁"],
    "江西": ["南昌","九江","景德镇","上饶","鹰潭","宜春","萍乡","赣州","吉安","抚州","新余"],
    "内蒙古": ["呼和浩特","包头","乌海","赤峰","通辽","锡林郭勒盟","阿拉善盟","兴安","鄂尔多斯","呼伦贝尔","巴彦淖尔","乌兰察布"],
    "宁夏": ["银川","石嘴山","固原","吴忠","中卫"],
    "青海": ["西宁","果洛","玉树","海西","海东地区","海北藏族自治州","黄南藏族自治州","海南藏族自治州"],
    "山东": ["青岛","威海","济南","淄博","聊城","德州","东营","潍坊","烟台","泰安","菏泽","临沂","枣庄","济宁","日照","滨州","莱芜"],
    "山西": ["太原","忻州","大同","临汾","运城","阳泉","长治","晋城","朔州","晋中","吕梁"],
    "陕西": ["西安","渭南","延安","榆林","宝鸡","安康","汉中","铜川","咸阳","商洛"],
    "四川": ["成都","乐山","凉山","绵阳","阿坝","雅安","甘孜","广元","南充","内江","自贡","宜宾","泸州","攀枝花","德阳","资阳","眉山","广安","遂宁","巴中","达州"],
    "云南": ["昆明","曲靖","昭通","文山","大理","楚雄","临沧","保山","玉溪","丽江","普洱","红河","西双版纳傣族自治州","德宏傣族景颇族自治州","怒江傈僳族自治州","迪庆藏族自治州"],
    "浙江": ["杭州","温州","宁波","绍兴","湖州","嘉兴","金华","丽水","衢州","台州","舟山"],
    "福建": ["福州","厦门","泉州","南平","漳州","龙岩","三明","莆田","宁德"],
    "黑龙江": ["哈尔滨","绥化","佳木斯","牡丹江","齐齐哈尔","大庆","大兴安岭","鸡西","鹤岗","双鸭山","伊春","黑河","七台河"],
    "吉林": ["长春","吉林","通化","四平","白城","松原","辽源","白山","延边朝鲜族自治州"],
    "辽宁": ["沈阳","铁岭","抚顺","鞍山","营口","大连","本溪","丹东","锦州","朝阳","阜新","盘锦","辽阳","葫芦岛"],
    "西藏": ["拉萨","那曲","昌都","山南","日喀则","阿里","林芝"],
    "新疆": ["乌鲁木齐","克拉玛依","阿勒泰","巴音郭楞","哈密","吐鲁番","阿克苏","喀什","和田","昌吉","塔城","克孜勒苏柯尔克孜自治州","博尔塔拉蒙古自治州","伊犁哈萨克自治州","自治区直辖县级"],
}
PROVINCE_CODE_MAP = {
    "北京": 10102000, "上海": 10103000, "广东": 10101000,
    "天津": 10104000, "重庆": 10105000, "安徽": 10106000,
    "福建": 10107000, "甘肃": 10108000, "广西": 10109000,
    "贵州": 10110000, "海南": 10111000, "河北": 10112000,
    "河南": 10113000, "黑龙江": 10114000, "湖北": 10115000,
    "湖南": 10116000, "吉林": 10117000, "江苏": 10118000,
    "江西": 10119000, "辽宁": 10120000, "内蒙古": 10121000,
    "宁夏": 10122000, "青海": 10123000, "山东": 10124000,
    "山西": 10125000, "陕西": 10126000, "四川": 10127000,
    "西藏": 10128000, "新疆": 10129000, "云南": 10130000,
    "浙江": 10131000,
}

# 大城市单独搜（突破省码1000人上限）
TOP_CITY_CODES = {
    "北京": 10102000, "上海": 10103000, "广州": 10101002,
    "深圳": 10101201, "成都": 10127001, "重庆": 10105000,
    "杭州": 10131001, "武汉": 10115001, "西安": 10126001,
    "郑州": 10113001, "南京": 10118001, "天津": 10104000,
    "长沙": 10116001, "东莞": 10101007, "佛山": 10101003,
    "合肥": 10106001, "济南": 10124003, "青岛": 10124001,
    "苏州": 10118002, "沈阳": 10120001, "大连": 10120006,
    "厦门": 10107002, "福州": 10107001,
}

ALL_PROVINCES = ["全國"] + sorted([p for p in PROVINCE_MAP if p not in EXCLUDED])

# ========== Flask App ==========
app = Flask(__name__)

# 全局状态
log_queue: queue.Queue = queue.Queue()
crawl_running = threading.Event()
crawl_thread = None
current_stats = {"total": 0, "by_province": {}}


def emit(msg: str):
    log_queue.put(msg)


def send_tg_report():
    """发送当前采集统计到 TG"""
    total = current_stats.get("total", 0)
    by_prov = current_stats.get("by_province", {})
    if total == 0:
        return
    lines = [f"📊 TON MAN 2.0 采集报告\n"]
    lines.append(f"今日采集: {total} 条\n")
    lines.append("各省份数量:")
    for prov, cities in by_prov.items():
        city_list = ", ".join(f"{c}:{n}" for c, n in cities.items())
        lines.append(f"  📍 {prov}: {city_list}")

    msg = "\n".join(lines)
    try:
        requests.post(
            f"https://api.telegram.org/bot{TG_BOT_TOKEN}/sendMessage",
            json={"chat_id": TG_CHAT_ID, "text": msg, "parse_mode": "Markdown"},
            timeout=10,
        )
    except Exception as e:
        print(f"TG 通知失败: {e}")

def _get_cert_daily_counts():
    """从主CSV统计今天/昨天/前天的实名数量，以及各城市分布"""
    from datetime import datetime
    main_csv = os.path.join(BASE_DIR, "zhenai_members.csv")
    if not os.path.exists(main_csv):
        return 0, 0, 0, 0, {}
    today = datetime.now().strftime("%Y-%m-%d")
    yday = datetime.fromtimestamp(time.time()-86400).strftime("%Y-%m-%d")
    dby = datetime.fromtimestamp(time.time()-172800).strftime("%Y-%m-%d")
    tc = yd = db = total = 0
    city_count = {}
    with open(main_csv, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            if len(row) >= 13:
                ct = row[12].strip()
                city = row[4].strip() if len(row) > 4 else ""
                if ct and ct != "无":
                    total += 1
                    if ct.startswith(today): tc += 1
                    elif ct.startswith(yday):
                        yd += 1
                        city_count.setdefault(city, {"yd": 0, "db": 0})["yd"] += 1
                    elif ct.startswith(dby):
                        db += 1
                        city_count.setdefault(city, {"yd": 0, "db": 0})["db"] += 1
    return total, tc, yd, db, city_count

def _get_main_total():
    """从主CSV获取总采集数"""
    main_csv = os.path.join(BASE_DIR, "zhenai_members.csv")
    if os.path.exists(main_csv):
        with open(main_csv, "r") as f:
            return sum(1 for _ in f) - 1
    return 0

def _get_current_city():
    """获取当前正在处理的城市"""
    pf = os.path.join(BASE_DIR, "city_progress.txt")
    if os.path.exists(pf):
        with open(pf, "r") as f:
            return f.read().strip()
    return "未开始"

def tg_hourly_reporter():
    """每30分钟播报"""
    last_total = 0
    time.sleep(10)
    while True:
        try:
            total = _get_main_total()
            cert_total, cert_today, cert_yd, cert_db, cert_cities = _get_cert_daily_counts()
            current_city = _get_current_city()
            crawl_running_now = crawl_running.is_set()

            # 今日增量 = 当前总数 - 今日起始数
            snap_file = os.path.join(BASE_DIR, "daily_snapshot.json")
            today_start = total
            if os.path.exists(snap_file):
                try:
                    with open(snap_file) as f:
                        snap = json.load(f)
                    if snap.get("date") == time.strftime("%Y-%m-%d"):
                        today_start = snap.get("start_total", total)
                except:
                    pass
            if today_start == total and not os.path.exists(snap_file):
                try:
                    with open(snap_file, "w") as f:
                        json.dump({"date": time.strftime("%Y-%m-%d"), "start_total": total}, f)
                except:
                    pass
            today_new = total - today_start

            lines = []
            lines.append('💵 八 方 来 财 💵')
            lines.append('━━━━━━━━━━')
            lines.append('📅 昨日采集总数: - 条')
            lines.append('━━━━━━━━━━')
            lines.append('📝 今日采集数量: ' + str(today_new) + ' 条')
            lines.append('💭 当天实名: ' + str(cert_today) + ' 条')
            lines.append('💭 昨日实名: ' + str(cert_yd) + ' 条')
            lines.append('💭 前天实名: ' + str(cert_db) + ' 条')
            lines.append('30天实名累计: ' + str(cert_total) + ' 条')
            lines.append('━━━━━━━━━━')
            if crawl_running_now:
                lines.append('🟢 采集中 | 📍 ' + current_city)
            else:
                lines.append('🔴 已停止 | 📍 ' + current_city)
            lines.append('⏰ ' + time.strftime('%H:%M'))

            if total != last_total:
                try:
                    requests.post(
                        'https://api.telegram.org/bot' + TG_BOT_TOKEN + '/sendMessage',
                        json={'chat_id': TG_CHAT_ID, 'text': chr(10).join(lines)},
                        timeout=10,
                    )
                except Exception as e:
                    pass
                last_total = total
        except Exception as e:
            pass
        time.sleep(1800)

# 启动定时报告线程
tg_thread = threading.Thread(target=tg_hourly_reporter, daemon=True)
tg_thread.start()

class LogCapture(io.StringIO):
    def write(self, s):
        super().write(s)
        for line in s.split("\n"):
            if line.strip():
                emit(line.strip())
    def flush(self):
        pass


def run_search(provinces, age_begin, age_end, gender, max_pages, extra=("", "", "")):
    crawler = ton.ZhenaiCrawler(token=MY_TOKEN, seedtoken=MY_SEED)
    cache_file = os.path.join(BASE_DIR, "scraped_ids.txt")
    output_file = os.path.join(BASE_DIR, "zhenai_members.csv")
    scraped = ton.load_scraped_ids(cache_file)
    gender_val = 1 if gender == "女" else 2
    if any(p in ("全國", "全国") for p in provinces):
        provinces = list(PROVINCE_MAP.keys())

    # 收集城市/省份 -- 省码覆盖全省 + 大城市单独搜突破API上限
    cities = []
    for p in provinces:
        if p in PROVINCE_CODE_MAP:
            cities.append((p, PROVINCE_CODE_MAP[p], p))
        elif p in PROVINCE_MAP:
            for c in PROVINCE_MAP[p]:
                if c in ton.CITY_CODE_MAP:
                    cities.append((c, ton.CITY_CODE_MAP[c], p))
    # 追加：大城市单独搜索（突破省码1000人上限）
    existing = set(code for _, code, _ in cities)
    for cname, ccode in TOP_CITY_CODES.items():
        if ccode not in existing:
            cities.append((cname, ccode, "大城市"))

    # 剔除福建：省码 10107000 及 厦门10107002/福州10107001
    FUJIAN_CODES = {10107000, 10107002, 10107001}
    cities = [c for c in cities if c[1] not in FUJIAN_CODES]

    total_new = 0
    current_stats["total"] = 0
    current_stats["by_province"] = {}

    # ====== 城市断点续传 ======
    progress_file = os.path.join(BASE_DIR, "city_progress.txt")
    last_city = ""
    if os.path.exists(progress_file):
        with open(progress_file, "r") as f:
            last_city = f.read().strip()
    skip_mode = bool(last_city)
    if skip_mode:
        emit(f"⏩ 续传模式：跳过已完成的 {last_city} 之前的城市...")

    for city_name, city_code, province in cities:
        # 跳过已完成的城市
        if skip_mode:
            if city_name == last_city:
                skip_mode = False  # 找到了，从这个城市开始
            else:
                continue  # 还没到，继续跳

        emit(f"\n📍 {city_name} ...")
        # 进城市就保存进度，中途停了也能续
        with open(progress_file, "w") as f:
            f.write(city_name)
        city_new = 0
        zero_streak = 0
        for page in range(1, max_pages + 1):
            time.sleep(0.3)
            members, has_next = crawler.search_members(
                page=page, page_size=20,
                age_begin=age_begin, age_end=age_end,
                work_city=city_code, gender=gender_val,
            )
            if not members:
                break
            ids = [m.get("memberId") or m.get("memberID") or m.get("objectID") for m in members
                   if m.get("memberId") or m.get("memberID") or m.get("objectID")]
            new_ids = [m for m in ids if str(m) not in scraped]
            if new_ids:
                zero_streak = 0
            else:
                zero_streak += 1
            emit(f"  📄 第{page}页: {len(ids)}人, 新{len(new_ids)}人")
            for mid in ids:
                if str(mid) in scraped or not crawl_running.is_set():
                    continue
                ok = ton.process_member(crawler, mid, scraped, cache_file, output_file, None, None, extra[:3], extra[3])
                if ok:
                    city_new += 1
                    total_new += 1
                time.sleep(0.3)
            if not has_next or not crawl_running.is_set():
                break
            # 连续10页没新人 → 提前跳到下一个省
            if zero_streak >= 10:
                emit(f"  ⏩ {city_name} 连续{zero_streak}页无新人，跳过剩余页")
                break
            time.sleep(0.3)
        # 更新全局统计
        current_stats.setdefault("by_province", {}).setdefault(province, {})[city_name] = city_new
        current_stats["total"] = total_new
        emit(f"  ✅ {city_name}: +{city_new} | 累计: {total_new}")
        # 保存城市进度
        with open(progress_file, "w") as f:
            f.write(city_name)
        # 发送统计快照
        stats_data = json.dumps(current_stats, ensure_ascii=False)
        emit("__STATS__:" + stats_data)
    # 全部完成，清空进度文件
    if os.path.exists(progress_file):
        os.remove(progress_file)
    emit(f"\n🎉 完成！共新增 {total_new} 条")


def run_circle(max_pages, gender, extra=("", "", "")):
    crawler = ton.ZhenaiCrawler(token=MY_TOKEN, seedtoken=MY_SEED)
    cache_file = os.path.join(BASE_DIR, "scraped_ids.txt")
    output_file = os.path.join(BASE_DIR, "zhenai_members.csv")
    scraped = ton.load_scraped_ids(cache_file)

    circles = crawler.get_circles()
    emit(f"发现 {len(circles)} 个相亲圈")
    total_new = 0
    for circle in circles:
        if not crawl_running.is_set():
            break
        cid = circle.get("circleId")
        cname = circle.get("circleName", "")
        emit(f"\n📌 {cname} ...")
        c_new = 0
        for page in range(1, max_pages + 1):
            moments, has_next = crawler.get_circle_moments(cid, page=page, page_size=20)
            if not moments:
                break
            ids = [(m.get("owner") or {}).get("memberID") or m.get("memberID") for m in moments
                   if (m.get("owner") or {}).get("memberID") or m.get("memberID")]
            new_ids = [m for m in ids if str(m) not in scraped]
            emit(f"  📄 第{page}页: {len(ids)}人, 新{len(new_ids)}人")
            for mid in ids:
                if str(mid) in scraped or not crawl_running.is_set():
                    continue
                ok = ton.process_member(crawler, mid, scraped, cache_file, output_file, None, None, extra[:3], extra[3])
                if ok:
                    c_new += 1
                    total_new += 1
                time.sleep(0.3)
            if not has_next:
                break
            time.sleep(0.3)
        emit(f"  ✅ {cname}: +{c_new} | 累计: {total_new}")
    emit(f"\n🎉 完成！共新增 {total_new} 条")


def run_recommend(max_pages, gender, extra=("", "", "")):
    crawler = ton.ZhenaiCrawler(token="", seedtoken=MY_SEED)
    cache_file = os.path.join(BASE_DIR, "scraped_ids.txt")
    output_file = os.path.join(BASE_DIR, "zhenai_members.csv")
    scraped = ton.load_scraped_ids(cache_file)
    gender_val = 1 if gender == "女" else 2
    if any(p in ("全國", "全国") for p in provinces):
        provinces = list(PROVINCE_MAP.keys())

    total_new = 0
    for page in range(1, max_pages + 1):
        if not crawl_running.is_set():
            break
        ids = crawler.get_recommend_list(page=page, page_size=20)
        if not ids:
            emit(f"第{page}页为空，停止")
            break
        new_ids = [m for m in ids if str(m) not in scraped]
        emit(f"📄 第{page}页: {len(ids)}人, 新{len(new_ids)}人")
        for mid in ids:
            if str(mid) in scraped or not crawl_running.is_set():
                continue
            ok = ton.process_member(crawler, mid, scraped, cache_file, output_file, "女" if gender_val == 1 else "男", None, extra[:3], extra[3])
            if ok:
                total_new += 1
            time.sleep(0.3)
        time.sleep(0.3)
    emit(f"\n🎉 完成！共新增 {total_new} 条")


def crawl_worker(mode, provinces, age_begin, age_end, gender, max_pages, extra=("", "", "")):
    old_stdout = sys.stdout
    sys.stdout = LogCapture()
    try:
        if mode == "搜索接口模式":
            run_search(provinces, age_begin, age_end, gender, max_pages, extra)
        elif mode == "动态列表模式":
            run_circle(max_pages, gender, extra)
        elif mode == "推荐模式":
            run_recommend(max_pages, gender, extra)
    except Exception as e:
        emit(f"\n❌ 错误: {e}")
        import traceback
        emit(traceback.format_exc())
    finally:
        sys.stdout = old_stdout
        crawl_running.clear()
        emit("__DONE__")


# ========== Routes ==========

@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE, provinces=["全國"] + ALL_PROVINCES)


@app.route("/start", methods=["POST"])
def start():
    global crawl_thread
    if crawl_running.is_set():
        return jsonify({"ok": False, "msg": "已有采集任务在运行"})

    data = request.get_json()
    mode = data.get("mode", "搜索接口模式")
    provinces = data.get("provinces", [])
    age_begin = int(data.get("age_begin", 40))
    age_end = int(data.get("age_end", 65))
    gender = data.get("gender", "女")
    max_pages = int(data.get("max_pages", 100))

    if mode == "搜索接口模式" and not provinces:
        return jsonify({"ok": False, "msg": "请至少选择一个省份"})

    # 清空旧日志
    while not log_queue.empty():
        log_queue.get()

    crawl_running.set()
    income_filter = data.get("income_filter", "")
    education_filter = data.get("education_filter", "")
    marriage_filter = data.get("marriage_filter", "")

    emit(f"🚀 开始采集 | 模式: {mode} | 年龄: {age_begin}-{age_end} | 性别: {gender}")
    if provinces:
        emit(f"🗺️ 省份: {', '.join(provinces)}")
    filters = []
    if income_filter: filters.append(f"💰{income_filter}")
    if education_filter: filters.append(f"🎓{education_filter}")
    if marriage_filter: filters.append(f"💍{marriage_filter}")
    if filters: emit(f"🔍 筛选: {', '.join(filters)}")

    cert_days = int(data.get("cert_days", 0))
    extra = (income_filter, education_filter, marriage_filter, cert_days)
    crawl_thread = threading.Thread(
        target=crawl_worker,
        args=(mode, provinces, age_begin, age_end, gender, max_pages, extra),
        daemon=True,
    )
    # ===== 启动报备：私聊 + 群 =====
    try:
        from datetime import datetime as _dt
        _report = "\U0001f680 采集启动报备\n"
        _report += "模式: " + mode + "\n"
        _report += "年龄: " + str(age_begin) + "-" + str(age_end) + "\n"
        _report += "性别: " + gender + "\n"
        _report += "省份: " + (", ".join(provinces) if provinces else "全国") + "\n"
        _report += "时间: " + _dt.now().strftime("%Y-%m-%d %H:%M:%S")
        for _cid in (TG_CHAT_ID, GROUP_CHAT_ID):
            requests.post(
                "https://api.telegram.org/bot" + TG_BOT_TOKEN + "/sendMessage",
                json={"chat_id": _cid, "text": _report},
                timeout=10,
            )
    except Exception as _e:
        print("启动报备失败: " + str(_e))

    crawl_thread.start()
    return jsonify({"ok": True})


@app.route("/stop", methods=["POST"])
def stop():
    crawl_running.clear()
    emit("⏹️ 已请求停止...")
    return jsonify({"ok": True})


@app.route("/stream")
def stream():
    def generate():
        # 新连接时，立即发送当前统计快照
        if current_stats["total"] > 0:
            stats_data = json.dumps(current_stats, ensure_ascii=False)
            yield f"event: stats\ndata: {stats_data}\n\n"
        while True:
            try:
                msg = log_queue.get(timeout=1)
                if msg == "__DONE__":
                    yield "data: {\"done\": true}\n\n"
                    break
                if msg.startswith("__STATS__:"):
                    yield f"event: stats\ndata: {msg[9:]}\n\n"
                else:
                    yield f"data: {json.dumps({'msg': msg})}\n\n"
            except queue.Empty:
                yield "data: {\"ping\": true}\n\n"
    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.route("/status")
def status():
    return jsonify({"running": crawl_running.is_set()})

@app.route("/api/stats")
def api_stats():
    return jsonify(current_stats)


@app.route("/download")
def download():
    path = os.path.join(BASE_DIR, "zhenai_members.csv")
    if os.path.exists(path):
        return send_file(path, as_attachment=True, download_name="zhenai_members.csv")
    return "文件尚未生成", 404


# ========== HTML 模板 ==========

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TON MAN 2.0 — 数据采集</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f0f2f5; color: #333; }
.header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; padding: 12px 24px; text-align: center; }
.header h1 { font-size: 20px; margin: 0; }
.layout { display: flex; height: calc(100vh - 52px); }
.sidebar { width: 540px; background: #fff; padding: 10px 16px; border-right: 1px solid #e8e8e8; overflow-y: auto; min-height: 0; }
.main { flex: 1; display: flex; flex-direction: column; }
.log-area { flex: 1; background: #1e1e1e; color: #d4d4d4; padding: 14px; overflow-y: auto; font-family: 'Courier New', monospace; font-size: 13px; line-height: 1.6; }
.log-area .line { white-space: pre-wrap; }
.actions { padding: 10px 16px; background: #fff; border-top: 1px solid #e8e8e8; display: flex; gap: 10px; align-items: center; }
.section { margin-bottom: 8px; }
.section h3 { font-size: 13px; color: #555; margin-bottom: 4px; border-bottom: 1.5px solid #667eea; padding-bottom: 2px; }
.province-grid { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 4px 8px; line-height: 1.7; }
.province-item { display: flex; align-items: center; gap: 3px; font-size: 12px; padding: 2px 4px; border-radius: 4px; cursor: pointer; user-select: none; }
.province-item:hover { background: #f0f2ff; }
.province-item input { accent-color: #667eea; }
.province-actions { display: flex; gap: 8px; margin-bottom: 4px; }
.province-actions button { font-size: 11px; padding: 3px 10px; border: 1px solid #d9d9d9; background: #fff; border-radius: 4px; cursor: pointer; }
.province-actions button:hover { border-color: #667eea; color: #667eea; }
.mode-row { display: flex; gap: 6px; }
.mode-btn { flex: 1; padding: 6px 8px; border: 2px solid #e8e8e8; background: #fff; border-radius: 6px; cursor: pointer; font-size: 12px; text-align: center; }
.mode-btn:hover { border-color: #667eea; }
.mode-btn.active { border-color: #667eea; background: #f0f2ff; font-weight: 600; }
.filter-row { display: flex; gap: 8px; align-items: center; margin-bottom: 5px; }
.filter-row label { font-size: 12px; color: #555; white-space: nowrap; }
.filter-row .val { font-weight: 600; color: #667eea; }
input[type=range] { flex: 1; }
select { font-size: 12px; padding: 4px 8px; border: 1px solid #d9d9d9; border-radius: 4px; }
.btn { padding: 10px 24px; border: none; border-radius: 8px; font-size: 15px; cursor: pointer; font-weight: 600; }
.btn-start { background: linear-gradient(135deg, #667eea, #764ba2); color: #fff; }
.btn-start:hover { opacity: 0.9; }
.btn-start:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-stop { background: #ff4d4f; color: #fff; }
.btn-download { background: #52c41a; color: #fff; text-decoration: none; padding: 10px 24px; border-radius: 8px; font-size: 15px; font-weight: 600; display: inline-block; }
.status { font-size: 13px; padding: 5px 12px; border-radius: 18px; }
.status.running { background: #fff7e6; color: #fa8c16; }
.status.idle { background: #f6ffed; color: #52c41a; }
.stats-panel { background: #fafafa; border-bottom: 1px solid #e8e8e8; padding: 8px 12px; max-height: 200px; overflow-y: auto; }
.stats-panel h4 { font-size: 13px; color: #555; margin: 0 0 4px 0; }
.stats-panel .total { font-size: 20px; font-weight: 700; color: #667eea; }
.stats-panel .province-block { display: inline-block; background: #fff; border: 1px solid #e8e8e8; border-radius: 6px; padding: 4px 8px; margin: 2px 4px 2px 0; font-size: 11px; }
.stats-panel .province-block .pname { font-weight: 600; color: #333; margin-bottom: 2px; }
.stats-panel .province-block .ccount { color: #999; font-size: 10px; }
</style>
</head>
<body>

<div class="header"><h1>💕 TON MAN 2.0</h1></div>

<div class="layout">
  <div class="sidebar">
    <div class="section">
      <h3>⚙️ 采集模式</h3>
      <div class="mode-row">
        <button class="mode-btn active" data-mode="搜索接口模式">搜索接口</button>
        <button class="mode-btn" data-mode="动态列表模式">动态列表</button>
        <button class="mode-btn" data-mode="推荐模式">推荐</button>
      </div>
    </div>

    <div class="section">
      <h3>🗺️ 省份 ({{ provinces|length }} 个可选)</h3>
      <div class="province-actions">
        <button onclick="selectAll()">✅ 全选</button>
        <button onclick="deselectAll()">❌ 全不选</button>
      </div>
      <div class="province-grid" id="provinceGrid">
        {% for p in provinces %}
        <label class="province-item">
          <input type="checkbox" value="{{ p }}" checked> {{ p }}
        </label>
        {% endfor %}
      </div>
    </div>

    <div class="section">
      
      <h3>🎯 筛选条件</h3>
      <div class="filter-row">
        <label>年龄: <span class="val" id="ageBeginVal">40</span></label>
        <input type="range" id="ageBegin" min="18" max="80" value="40" step="1">
        <label>至 <span class="val" id="ageEndVal">65</span></label>
        <input type="range" id="ageEnd" min="18" max="80" value="65" step="1">
      </div>
      <div class="filter-row">
        <label>性别</label>
        <select id="gender">
          <option value="女">女</option>
          <option value="男">男</option>
        </select>
        <label>最大页数: <span class="val" id="pagesVal">100</span></label>
        <input type="range" id="maxPages" min="5" max="500" value="100" step="5">
      </div>

      <div class="filter-row">
        <label>月收入</label>
        <select id="incomeFilter">
          <option value="">不限</option>
          <option value="3000元以下">3000元以下</option>
          <option value="3001-5000元">3001-5000元</option>
          <option value="5001-8000元">5001-8000元</option>
          <option value="8001-12000元">8001-12000元</option>
          <option value="12001-20000元">12001-20000元</option>
        </select>
        <label>学历</label>
        <select id="educationFilter">
          <option value="">不限</option>
          <option value="高中">高中</option>
          <option value="中专">中专</option>
          <option value="大专">大专</option>
          <option value="大学本科">大学本科</option>
          <option value="硕士">硕士</option>
          <option value="博士">博士</option>
        </select>
        <label>婚姻</label>
        <select id="marriageFilter">
          <option value="">不限</option>
          <option value="未婚">未婚</option>
          <option value="离异">离异</option>
          <option value="丧偶">丧偶</option>
        </select>
      </div>
      <div class="filter-row">
        <label><input type="checkbox" id="certDays" value="3" checked>🎯 仅采集3天内实名+紫图用户</label>
      </div>

    </div>
  </div>

  <div class="main">
    <div class="stats-panel" id="statsPanel" style="display:none;">
      <h4>📊 今日采集统计 · 总计: <span class="total" id="statsTotal">0</span> 条</h4>
      <div id="statsByProvince"></div>
    </div>
    <div class="log-area" id="log"><span style="color:#888;">等待开始...</span></div>
    <div class="actions">
      <button class="btn btn-start" id="btnStart" onclick="startCrawl()">🚀 开始采集</button>
      <button class="btn btn-stop" id="btnStop" onclick="stopCrawl()" disabled>⏹ 停止</button>
      <span class="status idle" id="status">⚪ 空闲</span>
      <span style="flex:1"></span>
      <a class="btn-download" id="btnDownload" href="/download" style="display:none;">📥 下载 CSV</a>
    </div>
  </div>
</div>

<script>
let eventSource = null;

// 页面加载：检查是否有正在运行的采集，恢复统计
fetch('/api/stats').then(r => r.json()).then(stats => {
  if (stats.total > 0) {
    renderStats(stats);
  }
});
fetch('/status').then(r => r.json()).then(s => {
  if (s.running) {
    document.getElementById('btnStart').disabled = true;
    document.getElementById('btnStop').disabled = false;
    document.getElementById('status').textContent = '🟡 运行中';
    document.getElementById('status').className = 'status running';
    reconnectStream();
  }
});

function renderStats(stats) {
  document.getElementById('statsPanel').style.display = 'block';
  document.getElementById('statsTotal').textContent = stats.total;
  let html = '';
  for (const [prov, cities] of Object.entries(stats.by_province)) {
    html += '<span class="province-block"><span class="pname">' + prov + '</span><br>';
    for (const [city, count] of Object.entries(cities)) {
      html += '<span class="ccount">' + city + ': ' + count + '</span> ';
    }
    html += '</span>';
  }
  document.getElementById('statsByProvince').innerHTML = html;
}

function reconnectStream() {
  if (eventSource) eventSource.close();
  eventSource = new EventSource('/stream');
  eventSource.addEventListener('stats', function(e) {
    renderStats(JSON.parse(e.data));
  });
  eventSource.onmessage = function(e) {
    const data = JSON.parse(e.data);
    if (data.done) {
      log('✅ 采集任务完成');
      done();
    } else if (data.msg) {
      log(data.msg);
    }
  };
  eventSource.onerror = function() { done(); };
}

// 模式选择
document.querySelectorAll('.mode-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');
  });
});

// 滑块实时显示
['ageBegin','ageEnd','maxPages'].forEach(id => {
  const el = document.getElementById(id);
  el.addEventListener('input', () => {
    document.getElementById(id+'Val').textContent = el.value;
  });
});

// 省份全选/全不选
function selectAll() {
  document.querySelectorAll('#provinceGrid input').forEach(cb => cb.checked = true);
}
function deselectAll() {
  document.querySelectorAll('#provinceGrid input').forEach(cb => cb.checked = false);
}

function getMode() {
  return document.querySelector('.mode-btn.active').dataset.mode;
}

function getProvinces() {
  const checked = document.querySelectorAll('#provinceGrid input:checked');
  return Array.from(checked).map(cb => cb.value);
}

function log(msg) {
  const logEl = document.getElementById('log');
  logEl.innerHTML += '<div class="line">' + msg + '</div>';
  logEl.scrollTop = logEl.scrollHeight;
}

function startCrawl() {
  const mode = getMode();
  const provinces = getProvinces();

  if (mode === '搜索接口模式' && provinces.length === 0) {
    alert('请至少选择一个省份');
    return;
  }

  fetch('/start', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      mode: mode,
      provinces: provinces,
      age_begin: Number(document.getElementById('ageBegin').value),
      age_end: Number(document.getElementById('ageEnd').value),
      gender: document.getElementById('gender').value,
      max_pages: Number(document.getElementById('maxPages').value),
      income_filter: document.getElementById('incomeFilter').value,
      education_filter: document.getElementById('educationFilter').value,
      marriage_filter: document.getElementById('marriageFilter').value,
      cert_days: document.getElementById('certDays').checked ? 3 : 0,
    })
  }).then(r => r.json()).then(resp => {
    if (!resp.ok) {
      alert(resp.msg);
      return;
    }
    // 开始监听日志
    document.getElementById('log').innerHTML = '';
    document.getElementById('btnStart').disabled = true;
    document.getElementById('btnStop').disabled = false;
    document.getElementById('status').textContent = '🟡 运行中';
    document.getElementById('status').className = 'status running';
    document.getElementById('btnDownload').style.display = 'none';

    // 显示统计面板
    document.getElementById('statsPanel').style.display = 'block';
    document.getElementById('statsTotal').textContent = '0';
    document.getElementById('statsByProvince').innerHTML = '';

    eventSource = new EventSource('/stream');
    eventSource.addEventListener('stats', function(e) {
      const stats = JSON.parse(e.data);
      document.getElementById('statsTotal').textContent = stats.total;
      let html = '';
      for (const [prov, cities] of Object.entries(stats.by_province)) {
        html += '<span class="province-block"><span class="pname">' + prov + '</span><br>';
        for (const [city, count] of Object.entries(cities)) {
          html += '<span class="ccount">' + city + ': ' + count + '</span> ';
        }
        html += '</span>';
      }
      document.getElementById('statsByProvince').innerHTML = html;
    });
    eventSource.onmessage = function(e) {
      const data = JSON.parse(e.data);
      if (data.done) {
        log('✅ 采集任务完成');
        done();
      } else if (data.msg) {
        log(data.msg);
      }
    };
    eventSource.onerror = function() {
      done();
    };
  });
}

function stopCrawl() {
  fetch('/stop', { method: 'POST' });
}

function done() {
  if (eventSource) { eventSource.close(); eventSource = null; }
  document.getElementById('btnStart').disabled = false;
  document.getElementById('btnStop').disabled = true;
  document.getElementById('status').textContent = '⚪ 空闲';
  document.getElementById('status').className = 'status idle';
  document.getElementById('btnDownload').style.display = 'inline-block';
}
</script>
</body>
</html>
"""

if __name__ == "__main__":
    print("🚀 TON MAN 2.0 启动 → http://localhost:7860")
    app.run(host="0.0.0.0", port=7860, debug=False, threaded=True)
