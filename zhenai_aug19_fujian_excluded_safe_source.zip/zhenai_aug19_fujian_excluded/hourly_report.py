#!/usr/bin/env python3
"""独立播报脚本 - crontab 每30分钟执行一次"""

import os, time, json, csv, requests
from datetime import datetime

BASE_DIR = "/root/zhenai"
TG_BOT_TOKEN = os.environ.get("TG_BOT_TOKEN", "")
TG_CHAT_ID = os.environ.get("TG_CHAT_ID", "")

def get_main_total():
    f = os.path.join(BASE_DIR, "zhenai_members.csv")
    if os.path.exists(f):
        with open(f) as fh:
            return sum(1 for _ in fh) - 1
    return 0

def get_cert_stats():
    f = os.path.join(BASE_DIR, "zhenai_members.csv")
    if not os.path.exists(f):
        return 0, 0, 0, 0
    today = datetime.now().strftime("%Y-%m-%d")
    yday = datetime.fromtimestamp(time.time()-86400).strftime("%Y-%m-%d")
    dby = datetime.fromtimestamp(time.time()-172800).strftime("%Y-%m-%d")
    tc = yd = db = total = 0
    with open(f, "r", encoding="utf-8-sig") as fh:
        reader = csv.reader(fh)
        next(reader)
        for row in reader:
            if len(row) >= 13:
                ct = row[12].strip()
                if ct and ct != "无":
                    total += 1
                    if ct.startswith(today): tc += 1
                    elif ct.startswith(yday): yd += 1
                    elif ct.startswith(dby): db += 1
    return total, tc, yd, db

def get_current_city():
    f = os.path.join(BASE_DIR, "city_progress.txt")
    if os.path.exists(f):
        with open(f) as fh:
            return fh.read().strip()
    return "未开始"

def is_crawling():
    import subprocess
    r = subprocess.run(["pgrep", "-f", "python3 gui.py"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return r.returncode == 0

# --- main ---
total = get_main_total()
cert_total, cert_today, cert_yd, cert_db = get_cert_stats()
city = get_current_city()
running = is_crawling()

# 今日增量
snap_file = os.path.join(BASE_DIR, "daily_snapshot.json")
today_start = total
if os.path.exists(snap_file):
    try:
        with open(snap_file) as f:
            snap = json.load(f)
        if snap.get("date") == datetime.now().strftime("%Y-%m-%d"):
            today_start = snap.get("start_total", total)
    except:
        pass
else:
    with open(snap_file, "w") as f:
        json.dump({"date": datetime.now().strftime("%Y-%m-%d"), "start_total": total}, f)

today_new = total - today_start

# 数据没变化就不发
state_file = os.path.join(BASE_DIR, ".last_report_total")
last_total = 0
if os.path.exists(state_file):
    with open(state_file) as f:
        last_total = int(f.read().strip() or 0)

if total == last_total and last_total > 0:
    # 没变化，不发
    pass
else:
    lines = []
    lines.append('\U0001f4b5 \u516b \u65b9 \u6765 \u8d22 \U0001f4b5')
    lines.append('\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501')
    lines.append('\U0001f4c5 \u6628\u65e5\u91c7\u96c6\u603b\u6570: - \u6761')
    lines.append('\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501')
    lines.append('\U0001f4dd \u4eca\u65e5\u91c7\u96c6\u6570\u91cf: ' + str(today_new) + ' \u6761')
    lines.append('\U0001f4ad \u5f53\u5929\u5b9e\u540d: ' + str(cert_today) + ' \u6761')
    lines.append('\U0001f4ad \u6628\u65e5\u5b9e\u540d: ' + str(cert_yd) + ' \u6761')
    lines.append('\U0001f4ad \u524d\u5929\u5b9e\u540d: ' + str(cert_db) + ' \u6761')
    lines.append('30\u5929\u5b9e\u540d\u7d2f\u8ba1: ' + str(cert_total) + ' \u6761')
    lines.append('\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501')
    if running:
        lines.append('\U0001f7e2 \u91c7\u96c6\u4e2d | \U0001f4cd ' + city)
    else:
        lines.append('\U0001f534 \u5df2\u505c\u6b62 | \U0001f4cd ' + city)
    lines.append('\u23f0 ' + time.strftime('%H:%M'))

    msg = '\n'.join(lines)
    try:
        resp = requests.post(
            'https://api.telegram.org/bot' + TG_BOT_TOKEN + '/sendMessage',
            json={'chat_id': TG_CHAT_ID, 'text': msg},
            timeout=10
        )
        if resp.status_code == 200:
            with open(state_file, "w") as f:
                f.write(str(total))
        else:
            with open(os.path.join(BASE_DIR, "tg_error.log"), "a") as f:
                f.write(time.strftime('%H:%M') + ' crontab report fail: ' + resp.text[:100] + '\n')
    except Exception as e:
        with open(os.path.join(BASE_DIR, "tg_error.log"), "a") as f:
            f.write(time.strftime('%H:%M') + ' crontab report error: ' + str(e) + '\n')
